cd veritable-network/

docker ps -a

./veritable-network.sh up -o etcdraft -l node -s couchdb